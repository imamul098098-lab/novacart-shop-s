export interface Product {
  id: string;
  title: string;
  price: number;
  originalPrice: number;
  discount: number;
  rating: number;
  reviews: number;
  image: string;
  images: string[];
  category: string;
  subcategory: string;
  seller: string;
  stock: number;
  description: string;
  specifications: Record<string, string>;
  isFlashSale?: boolean;
  isTrending?: boolean;
  isBestSeller?: boolean;
  colors?: string[];
  sizes?: string[];
}

const categories = [
  "Electronics", "Men's Fashion", "Women's Fashion", "Shoes",
  "Beauty", "Accessories", "Home & Living", "Gadgets"
];

const productTemplates: Record<string, { names: string[]; specs: Record<string, string>; priceRange: [number, number]; sizes?: string[]; colors?: string[] }> = {
  "Electronics": {
    names: ["Wireless Bluetooth Headphones", "Smart Watch Pro", "Portable Speaker", "USB-C Hub Adapter", "Mechanical Keyboard RGB", "Wireless Mouse Ergonomic", "Webcam HD 1080p", "Power Bank 20000mAh", "Tablet Stand Adjustable", "LED Desk Lamp Smart", "Noise Cancelling Earbuds", "Mini Projector HD", "External SSD 1TB", "Wireless Charger Pad", "Smart Home Hub", "Bluetooth Transmitter", "Gaming Headset 7.1", "USB Microphone Studio", "Cable Management Kit", "Screen Protector Pack", "Laptop Cooling Pad", "Smart Plug WiFi", "Digital Photo Frame", "Car Phone Mount", "Ring Light 10 inch"],
    specs: { "Connectivity": "Bluetooth 5.0", "Battery": "Up to 30 hours", "Warranty": "1 Year" },
    priceRange: [15, 299],
    colors: ["Black", "White", "Silver", "Blue"],
  },
  "Men's Fashion": {
    names: ["Slim Fit Cotton Shirt", "Classic Denim Jeans", "Casual Polo T-Shirt", "Formal Blazer Jacket", "Chino Pants Stretch", "Graphic Print Hoodie", "Linen Summer Shirt", "Track Pants Jogger", "V-Neck Sweater Knit", "Cargo Shorts Premium", "Oxford Button Down", "Leather Belt Classic", "Wool Overcoat Long", "Athletic Shorts Dry-Fit", "Flannel Plaid Shirt", "Bomber Jacket Nylon", "Henley Long Sleeve", "Corduroy Trousers", "Windbreaker Light", "Tank Top Muscle Fit", "Dress Pants Tailored", "Quilted Vest Padded", "Terry Cloth Robe", "Swim Trunks Board", "Thermal Underwear Set"],
    specs: { "Material": "100% Cotton", "Fit": "Regular Fit", "Care": "Machine Washable" },
    priceRange: [12, 120],
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: ["Black", "White", "Navy", "Grey", "Khaki"],
  },
  "Women's Fashion": {
    names: ["Floral Maxi Dress", "High Waist Skinny Jeans", "Silk Blouse Elegant", "Knit Cardigan Cozy", "A-Line Midi Skirt", "Wrap Dress V-Neck", "Crop Top Ribbed", "Wide Leg Palazzo Pants", "Tunic Top Bohemian", "Peplum Blouse Formal", "Denim Jacket Cropped", "Pleated Trousers", "Off-Shoulder Sweater", "Pencil Skirt Classic", "Romper Jumpsuit", "Trench Coat Belted", "Lace Camisole", "Culottes High Rise", "Puffer Jacket Short", "Bodycon Dress Mini", "Blazer Oversized", "Yoga Leggings High Waist", "Satin Slip Dress", "Cable Knit Pullover", "Linen Shorts Summer"],
    specs: { "Material": "Polyester Blend", "Fit": "Regular", "Care": "Hand Wash Recommended" },
    priceRange: [10, 150],
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: ["Black", "White", "Pink", "Red", "Beige", "Navy"],
  },
  "Shoes": {
    names: ["Running Sneakers Lightweight", "Classic Leather Loafers", "Canvas Slip-On Casual", "Hiking Boots Waterproof", "Formal Oxford Shoes", "Platform Sandals Summer", "Athletic Training Shoes", "Chelsea Boots Suede", "Flip Flops Comfort", "High Top Sneakers", "Ballet Flats Pointed", "Work Boots Steel Toe", "Espadrilles Woven", "Slides Pool Comfort", "Moccasins Driving", "Wedge Heels Strappy", "Trail Running Shoes", "Boat Shoes Classic", "Knee High Boots", "Sneakers Retro Vintage", "Ankle Boots Chunky", "Sandals Gladiator", "Clogs Garden", "Tennis Shoes Court", "Slippers House Cozy"],
    specs: { "Sole": "Rubber", "Upper": "Mesh/Synthetic", "Closure": "Lace-up" },
    priceRange: [20, 180],
    sizes: ["6", "7", "8", "9", "10", "11", "12"],
    colors: ["Black", "White", "Brown", "Grey", "Red"],
  },
  "Beauty": {
    names: ["Vitamin C Face Serum", "Moisturizing Cream SPF30", "Matte Lipstick Collection", "Eye Shadow Palette 18-Color", "Hair Growth Oil Natural", "Face Wash Gentle Foam", "BB Cream Foundation", "Mascara Volume Boost", "Night Cream Anti-Aging", "Perfume Eau de Toilette", "Nail Polish Set Gel", "Face Mask Sheet Pack", "Sunscreen Lotion SPF50", "Lip Gloss Hydrating", "Concealer Stick Full Coverage", "Blush Powder Compact", "Hair Straightener Ceramic", "Makeup Brush Set 12pc", "Toner Rose Water", "Body Lotion Shea Butter", "Eyeliner Waterproof Pen", "Setting Spray Matte", "Facial Cleanser Salicylic", "Hand Cream Repair", "Dry Shampoo Volumizing"],
    specs: { "Volume": "50ml", "Type": "All Skin Types", "Shelf Life": "24 months" },
    priceRange: [5, 80],
  },
  "Accessories": {
    names: ["Leather Wallet Bifold", "Sunglasses Polarized UV400", "Analog Watch Classic", "Crossbody Bag Canvas", "Beanie Hat Winter", "Silk Scarf Print", "Laptop Backpack 15.6 inch", "Stainless Steel Bracelet", "Travel Duffel Bag", "Phone Case Shockproof", "Umbrella Automatic Wind", "Tote Bag Large Canvas", "Cufflinks Silver Set", "Baseball Cap Embroidered", "Messenger Bag Vintage", "Pendant Necklace Gold", "Waist Bag Fanny Pack", "Keychain Leather Premium", "Stud Earrings Crystal", "Reading Glasses Blue Light", "Tie Set Silk Pattern", "Bucket Hat Cotton", "Ring Band Titanium", "Card Holder RFID", "Hair Accessories Set"],
    specs: { "Material": "Premium Quality", "Warranty": "6 Months" },
    priceRange: [5, 120],
    colors: ["Black", "Brown", "Silver", "Gold"],
  },
  "Home & Living": {
    names: ["Throw Pillow Cover Set", "Scented Candle Soy Wax", "Wall Art Canvas Print", "Bedsheet Set 400TC", "Kitchen Knife Set 6pc", "Ceramic Flower Vase", "Storage Basket Woven", "Table Lamp Modern", "Door Mat Welcome", "Curtains Blackout Pair", "Coffee Mug Set 4pc", "Bath Towel Set Luxury", "Spice Rack Organizer", "Picture Frame Gallery", "Area Rug Geometric", "Coaster Set Marble", "Laundry Hamper Foldable", "Bookend Set Modern", "Planter Pot Ceramic", "Clock Wall Modern", "Blanket Fleece Throw", "Soap Dispenser Set", "Shelf Floating Wall", "Cutting Board Bamboo", "Wine Glass Set Crystal"],
    specs: { "Material": "Premium Quality", "Care": "Easy Clean" },
    priceRange: [8, 150],
    colors: ["White", "Grey", "Natural", "Black"],
  },
  "Gadgets": {
    names: ["Drone Camera 4K", "Fitness Tracker Band", "VR Headset Standalone", "Robot Vacuum Cleaner", "Action Camera Waterproof", "Smart Door Lock", "Electric Toothbrush Sonic", "Air Purifier HEPA", "Handheld Gimbal Stabilizer", "Portable Blender USB", "Smart Scale Body Comp", "GPS Tracker Mini", "Electric Kettle Fast", "Massage Gun Percussion", "Night Vision Binoculars", "3D Printer Mini", "Metal Detector Pro", "Solar Power Bank", "Smart Water Bottle", "Thermal Camera Phone", "Pet Camera WiFi", "Laser Measure Tool", "Electric Screwdriver Set", "Weather Station Digital", "Smart Garden Indoor"],
    specs: { "Power": "Rechargeable", "Connectivity": "WiFi/Bluetooth", "Warranty": "1 Year" },
    priceRange: [20, 450],
    colors: ["Black", "White", "Grey"],
  },
};

const sellers = [
  "TechWorld Store", "FashionHub", "StyleZone", "GadgetPro", "BeautyGlow",
  "HomeEssentials", "ShoeParadise", "TrendyKicks", "ElectroMart", "LuxeFinds",
  "MegaDeals", "PremiumPicks", "ValueMart", "TopSeller", "QualityFirst"
];

function generateImageUrl(category: string, index: number): string {
  const seeds: Record<string, string[]> = {
    "Electronics": ["headphones", "smartwatch", "speaker", "keyboard", "mouse", "laptop", "camera", "phone"],
    "Men's Fashion": ["shirt", "jacket", "pants", "sweater", "hoodie", "blazer", "coat", "jeans"],
    "Women's Fashion": ["dress", "blouse", "skirt", "cardigan", "top", "jumpsuit", "coat", "pants"],
    "Shoes": ["sneakers", "boots", "sandals", "loafers", "heels", "flats", "running", "casual"],
    "Beauty": ["serum", "cream", "lipstick", "palette", "perfume", "skincare", "makeup", "beauty"],
    "Accessories": ["wallet", "sunglasses", "watch", "bag", "hat", "jewelry", "bracelet", "ring"],
    "Home & Living": ["pillow", "candle", "lamp", "kitchen", "decor", "bedding", "vase", "rug"],
    "Gadgets": ["drone", "tracker", "robot", "camera", "gadget", "smart", "tech", "device"],
  };
  const categorySeeds = seeds[category] || ["product"];
  const seed = categorySeeds[index % categorySeeds.length];
  return `https://images.unsplash.com/photo-${1500000000000 + (index * 17 + category.length * 31)}?w=400&h=400&fit=crop&q=80`;
}

// Use picsum for reliable placeholder images
function getProductImage(id: number): string {
  return `https://picsum.photos/seed/product${id}/400/400`;
}

function generateProducts(): Product[] {
  const products: Product[] = [];
  let id = 1;

  for (const category of categories) {
    const template = productTemplates[category];
    const { names, specs, priceRange, sizes, colors } = template;

    // Generate ~250 products per category (8 categories × 250 = 2000)
    for (let i = 0; i < 250; i++) {
      const nameIndex = i % names.length;
      const variant = Math.floor(i / names.length) + 1;
      const title = variant > 1 ? `${names[nameIndex]} V${variant}` : names[nameIndex];
      
      const originalPrice = Math.round((priceRange[0] + Math.random() * (priceRange[1] - priceRange[0])) * 100) / 100;
      const discountPercent = Math.floor(Math.random() * 60) + 5;
      const price = Math.round(originalPrice * (1 - discountPercent / 100) * 100) / 100;
      const rating = Math.round((3 + Math.random() * 2) * 10) / 10;
      const reviews = Math.floor(Math.random() * 5000) + 10;

      const productId = id++;
      const imageBase = getProductImage(productId);

      products.push({
        id: `p${productId}`,
        title,
        price,
        originalPrice,
        discount: discountPercent,
        rating,
        reviews,
        image: imageBase,
        images: [imageBase, getProductImage(productId + 2000), getProductImage(productId + 4000), getProductImage(productId + 6000)],
        category,
        subcategory: names[nameIndex].split(" ").slice(0, 2).join(" "),
        seller: sellers[productId % sellers.length],
        stock: Math.floor(Math.random() * 500) + 1,
        description: `High quality ${title} from our ${category} collection. Perfect for everyday use with premium build quality and excellent value for money. This product features top-notch materials and modern design that suits any lifestyle.`,
        specifications: { ...specs, "SKU": `NC-${productId.toString().padStart(6, '0')}`, "Weight": `${(Math.random() * 2 + 0.1).toFixed(1)} kg` },
        isFlashSale: Math.random() < 0.08,
        isTrending: Math.random() < 0.1,
        isBestSeller: Math.random() < 0.1,
        colors,
        sizes,
      });
    }
  }

  return products;
}

export const allProducts = generateProducts();

export const getProductById = (id: string) => allProducts.find(p => p.id === id);

export const getProductsByCategory = (category: string) => allProducts.filter(p => p.category === category);

export const getFlashSaleProducts = () => allProducts.filter(p => p.isFlashSale).slice(0, 20);

export const getTrendingProducts = () => allProducts.filter(p => p.isTrending).slice(0, 20);

export const getBestSellerProducts = () => allProducts.filter(p => p.isBestSeller).slice(0, 20);

export const searchProducts = (query: string) => {
  const q = query.toLowerCase();
  return allProducts.filter(p => 
    p.title.toLowerCase().includes(q) || 
    p.category.toLowerCase().includes(q) ||
    p.description.toLowerCase().includes(q)
  );
};

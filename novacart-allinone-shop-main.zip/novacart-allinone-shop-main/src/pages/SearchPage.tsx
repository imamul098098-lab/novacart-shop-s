import { useState, useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import { SlidersHorizontal, X } from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import ProductCard from "@/components/product/ProductCard";
import { searchProducts, allProducts } from "@/data/products";

const categories = ["All", "Electronics", "Men's Fashion", "Women's Fashion", "Shoes", "Beauty", "Accessories", "Home & Living", "Gadgets"];
const sortOptions = [
  { value: "relevant", label: "Most Relevant" },
  { value: "newest", label: "Newest" },
  { value: "price-asc", label: "Price: Low to High" },
  { value: "price-desc", label: "Price: High to Low" },
  { value: "rating", label: "Top Rated" },
  { value: "best", label: "Best Selling" },
];

const SearchPage = () => {
  const [params] = useSearchParams();
  const query = params.get("q") || "";
  const [category, setCategory] = useState("All");
  const [sort, setSort] = useState("relevant");
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 500]);
  const [minRating, setMinRating] = useState(0);
  const [showFilters, setShowFilters] = useState(false);
  const [page, setPage] = useState(1);
  const perPage = 24;

  const results = useMemo(() => {
    let products = query ? searchProducts(query) : [...allProducts];
    if (category !== "All") products = products.filter(p => p.category === category);
    products = products.filter(p => p.price >= priceRange[0] && p.price <= priceRange[1]);
    if (minRating > 0) products = products.filter(p => p.rating >= minRating);

    switch (sort) {
      case "price-asc": products.sort((a, b) => a.price - b.price); break;
      case "price-desc": products.sort((a, b) => b.price - a.price); break;
      case "rating": products.sort((a, b) => b.rating - a.rating); break;
      case "best": products.sort((a, b) => b.reviews - a.reviews); break;
      case "newest": products.sort((a, b) => parseInt(b.id.slice(1)) - parseInt(a.id.slice(1))); break;
    }
    return products;
  }, [query, category, sort, priceRange, minRating]);

  const paginated = results.slice(0, page * perPage);
  const hasMore = paginated.length < results.length;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container py-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-xl font-bold">{query ? `Results for "${query}"` : "All Products"}</h1>
            <p className="text-sm text-muted-foreground">{results.length} products found</p>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={() => setShowFilters(!showFilters)} className="lg:hidden flex items-center gap-1.5 px-3 py-2 border rounded-md text-sm">
              <SlidersHorizontal className="w-4 h-4" /> Filters
            </button>
            <select value={sort} onChange={e => setSort(e.target.value)} className="h-9 px-3 border rounded-md text-sm bg-background">
              {sortOptions.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          </div>
        </div>

        <div className="flex gap-6">
          {/* Filters Sidebar */}
          <aside className={`w-56 flex-shrink-0 space-y-6 ${showFilters ? "fixed inset-0 z-50 bg-card p-6 overflow-auto lg:static lg:p-0" : "hidden lg:block"}`}>
            {showFilters && <button onClick={() => setShowFilters(false)} className="lg:hidden absolute top-4 right-4"><X className="w-5 h-5" /></button>}
            
            <div>
              <h3 className="font-semibold text-sm mb-2">Category</h3>
              <div className="space-y-1">
                {categories.map(c => (
                  <button key={c} onClick={() => { setCategory(c); setPage(1); }} className={`block w-full text-left px-2 py-1.5 text-sm rounded ${category === c ? "bg-primary/10 text-primary font-medium" : "text-muted-foreground hover:bg-secondary"}`}>
                    {c}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <h3 className="font-semibold text-sm mb-2">Price Range</h3>
              <div className="flex items-center gap-2">
                <input type="number" value={priceRange[0]} onChange={e => setPriceRange([+e.target.value, priceRange[1]])} className="w-20 h-8 px-2 border rounded text-sm bg-background" />
                <span className="text-muted-foreground">-</span>
                <input type="number" value={priceRange[1]} onChange={e => setPriceRange([priceRange[0], +e.target.value])} className="w-20 h-8 px-2 border rounded text-sm bg-background" />
              </div>
            </div>

            <div>
              <h3 className="font-semibold text-sm mb-2">Min Rating</h3>
              <div className="space-y-1">
                {[4, 3, 2, 1, 0].map(r => (
                  <button key={r} onClick={() => { setMinRating(r); setPage(1); }} className={`block w-full text-left px-2 py-1.5 text-sm rounded ${minRating === r ? "bg-primary/10 text-primary font-medium" : "text-muted-foreground hover:bg-secondary"}`}>
                    {r === 0 ? "All Ratings" : `${r}+ Stars`}
                  </button>
                ))}
              </div>
            </div>
          </aside>

          {/* Results */}
          <div className="flex-1">
            {results.length === 0 ? (
              <div className="py-20 text-center">
                <p className="text-lg font-medium mb-2">No products found</p>
                <p className="text-sm text-muted-foreground">Try adjusting your filters or search terms.</p>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 lg:grid-cols-4 gap-3">
                  {paginated.map(p => <ProductCard key={p.id} product={p} />)}
                </div>
                {hasMore && (
                  <div className="text-center mt-8">
                    <button onClick={() => setPage(p => p + 1)} className="bg-primary text-primary-foreground px-8 py-2.5 rounded-lg font-medium hover:opacity-90">
                      Load More Products
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default SearchPage;

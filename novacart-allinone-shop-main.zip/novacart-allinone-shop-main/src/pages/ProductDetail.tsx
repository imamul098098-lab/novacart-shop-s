import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Star, ShoppingCart, Heart, ChevronLeft, Minus, Plus, Truck, Shield, RotateCcw } from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import ProductCard from "@/components/product/ProductCard";
import { getProductById, getProductsByCategory } from "@/data/products";
import { useCart } from "@/contexts/CartContext";
import { useWishlist } from "@/contexts/WishlistContext";
import { toast } from "sonner";

const ProductDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const product = getProductById(id || "");
  const { addToCart } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();

  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [selectedColor, setSelectedColor] = useState(product?.colors?.[0] || "");
  const [selectedSize, setSelectedSize] = useState(product?.sizes?.[0] || "");
  const [activeTab, setActiveTab] = useState<"description" | "specs" | "reviews">("description");

  if (!product) return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="container py-20 text-center">
        <h1 className="text-2xl font-bold mb-4">Product Not Found</h1>
        <button onClick={() => navigate("/")} className="text-primary hover:underline">Back to Home</button>
      </div>
      <Footer />
    </div>
  );

  const wishlisted = isInWishlist(product.id);
  const related = getProductsByCategory(product.category).filter(p => p.id !== product.id).slice(0, 6);

  const handleAddToCart = () => { addToCart(product, quantity, selectedColor, selectedSize); toast.success("Added to cart!"); };
  const handleBuyNow = () => { addToCart(product, quantity, selectedColor, selectedSize); navigate("/cart"); };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container py-4">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-muted-foreground mb-4">
          <button onClick={() => navigate(-1)} className="flex items-center gap-1 hover:text-primary"><ChevronLeft className="w-3 h-3" />Back</button>
          <span>/</span><span>{product.category}</span><span>/</span><span className="text-foreground">{product.title}</span>
        </div>

        {/* Product Layout */}
        <div className="grid md:grid-cols-2 gap-8">
          {/* Images */}
          <div>
            <div className="aspect-square rounded-lg overflow-hidden bg-secondary mb-3">
              <img src={product.images[selectedImage]} alt={product.title} className="w-full h-full object-cover" />
            </div>
            <div className="flex gap-2">
              {product.images.map((img, i) => (
                <button key={i} onClick={() => setSelectedImage(i)} className={`w-16 h-16 rounded-md overflow-hidden border-2 ${i === selectedImage ? "border-primary" : "border-transparent"}`}>
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* Details */}
          <div>
            <p className="text-xs text-muted-foreground mb-1">Sold by: <span className="text-primary font-medium">{product.seller}</span></p>
            <h1 className="text-xl font-bold text-foreground mb-2">{product.title}</h1>

            <div className="flex items-center gap-2 mb-3">
              <div className="flex">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className={`w-4 h-4 ${i < Math.round(product.rating) ? "fill-rating text-rating" : "text-muted"}`} />
                ))}
              </div>
              <span className="text-sm text-muted-foreground">{product.rating} ({product.reviews} reviews)</span>
            </div>

            <div className="flex items-baseline gap-3 mb-4 pb-4 border-b">
              <span className="text-3xl font-black text-sale">${product.price.toFixed(2)}</span>
              <span className="text-lg text-muted-foreground line-through">${product.originalPrice.toFixed(2)}</span>
              <span className="bg-sale/10 text-sale text-xs font-bold px-2 py-1 rounded">-{product.discount}%</span>
            </div>

            {/* Colors */}
            {product.colors && product.colors.length > 0 && (
              <div className="mb-4">
                <h3 className="text-sm font-semibold mb-2">Color: <span className="font-normal text-muted-foreground">{selectedColor}</span></h3>
                <div className="flex gap-2">
                  {product.colors.map(c => (
                    <button key={c} onClick={() => setSelectedColor(c)} className={`px-3 py-1.5 text-sm border rounded-md ${selectedColor === c ? "border-primary bg-primary/5 text-primary font-medium" : "border-input text-muted-foreground hover:border-foreground"}`}>
                      {c}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Sizes */}
            {product.sizes && product.sizes.length > 0 && (
              <div className="mb-4">
                <h3 className="text-sm font-semibold mb-2">Size: <span className="font-normal text-muted-foreground">{selectedSize}</span></h3>
                <div className="flex gap-2">
                  {product.sizes.map(s => (
                    <button key={s} onClick={() => setSelectedSize(s)} className={`w-10 h-10 text-sm border rounded-md flex items-center justify-center ${selectedSize === s ? "border-primary bg-primary/5 text-primary font-medium" : "border-input text-muted-foreground hover:border-foreground"}`}>
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity */}
            <div className="mb-4">
              <h3 className="text-sm font-semibold mb-2">Quantity</h3>
              <div className="flex items-center gap-3">
                <button onClick={() => setQuantity(q => Math.max(1, q - 1))} className="w-8 h-8 border rounded-md flex items-center justify-center hover:bg-secondary"><Minus className="w-4 h-4" /></button>
                <span className="text-sm font-semibold w-8 text-center">{quantity}</span>
                <button onClick={() => setQuantity(q => q + 1)} className="w-8 h-8 border rounded-md flex items-center justify-center hover:bg-secondary"><Plus className="w-4 h-4" /></button>
                <span className="text-xs text-muted-foreground">{product.stock} available</span>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-3 mb-6">
              <button onClick={handleBuyNow} className="flex-1 bg-sale text-sale-foreground font-semibold py-3 rounded-lg hover:opacity-90 transition-opacity">Buy Now</button>
              <button onClick={handleAddToCart} className="flex-1 bg-primary text-primary-foreground font-semibold py-3 rounded-lg hover:opacity-90 transition-opacity flex items-center justify-center gap-2">
                <ShoppingCart className="w-4 h-4" /> Add to Cart
              </button>
              <button onClick={() => { wishlisted ? removeFromWishlist(product.id) : addToWishlist(product); toast.success(wishlisted ? "Removed" : "Added to wishlist"); }} className="p-3 border rounded-lg hover:bg-secondary transition-colors">
                <Heart className={`w-5 h-5 ${wishlisted ? "fill-sale text-sale" : "text-muted-foreground"}`} />
              </button>
            </div>

            {/* Trust badges */}
            <div className="grid grid-cols-3 gap-3 py-4 border-t">
              <div className="flex items-center gap-2 text-xs text-muted-foreground"><Truck className="w-4 h-4 text-primary" />Free Shipping</div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground"><Shield className="w-4 h-4 text-primary" />Secure Payment</div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground"><RotateCcw className="w-4 h-4 text-primary" />Easy Returns</div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="mt-8 border-t pt-6">
          <div className="flex gap-6 border-b mb-4">
            {(["description", "specs", "reviews"] as const).map(tab => (
              <button key={tab} onClick={() => setActiveTab(tab)} className={`pb-3 text-sm font-medium capitalize border-b-2 transition-colors ${activeTab === tab ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}>
                {tab === "specs" ? "Specifications" : tab}
              </button>
            ))}
          </div>
          {activeTab === "description" && <p className="text-sm text-muted-foreground leading-relaxed max-w-3xl">{product.description}</p>}
          {activeTab === "specs" && (
            <table className="w-full max-w-lg text-sm">
              <tbody>
                {Object.entries(product.specifications).map(([key, val]) => (
                  <tr key={key} className="border-b">
                    <td className="py-2 font-medium text-foreground w-1/3">{key}</td>
                    <td className="py-2 text-muted-foreground">{val}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          {activeTab === "reviews" && (
            <div className="space-y-4 max-w-2xl">
              {[5, 4, 3].map(r => (
                <div key={r} className="border rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className={`w-3 h-3 ${i < r ? "fill-rating text-rating" : "text-muted"}`} />)}</div>
                    <span className="text-xs text-muted-foreground">Verified Buyer</span>
                  </div>
                  <p className="text-sm text-muted-foreground">Great product! Quality is excellent and delivery was fast. Highly recommended for everyone.</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Related */}
        <div className="mt-10">
          <h2 className="text-xl font-bold mb-4">Related Products</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {related.map(p => <ProductCard key={p.id} product={p} />)}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ProductDetail;

import { Link } from "react-router-dom";
import { Heart, ShoppingCart } from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import ProductCard from "@/components/product/ProductCard";
import { useWishlist } from "@/contexts/WishlistContext";

const Wishlist = () => {
  const { items } = useWishlist();

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container py-6">
        <h1 className="text-2xl font-bold mb-6">My Wishlist ({items.length} items)</h1>
        {items.length === 0 ? (
          <div className="py-20 text-center">
            <Heart className="w-16 h-16 text-muted mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">Your Wishlist is Empty</h2>
            <p className="text-muted-foreground mb-6">Save items you love for later.</p>
            <Link to="/" className="bg-primary text-primary-foreground px-6 py-2.5 rounded-lg font-medium hover:opacity-90">Explore Products</Link>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
            {items.map(p => <ProductCard key={p.id} product={p} />)}
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
};

export default Wishlist;

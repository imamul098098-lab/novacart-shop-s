import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { CreditCard, Truck, Building, DollarSign, Check } from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { useCart } from "@/contexts/CartContext";
import { toast } from "sonner";

const paymentMethods = [
  { id: "card", label: "Credit / Debit Card", icon: CreditCard },
  { id: "paypal", label: "PayPal", icon: DollarSign },
  { id: "bank", label: "Bank Transfer", icon: Building },
  { id: "cod", label: "Cash on Delivery", icon: Truck },
];

const Checkout = () => {
  const { items, totalPrice, discount, clearCart } = useCart();
  const navigate = useNavigate();
  const [step, setStep] = useState<"shipping" | "payment" | "confirm">("shipping");
  const [paymentMethod, setPaymentMethod] = useState("card");
  const [orderPlaced, setOrderPlaced] = useState(false);

  const [form, setForm] = useState({ firstName: "", lastName: "", email: "", phone: "", address: "", city: "", state: "", zip: "", country: "United States" });
  const updateForm = (key: string, val: string) => setForm(prev => ({ ...prev, [key]: val }));

  const subtotal = items.reduce((s, i) => s + i.product.price * i.quantity, 0);

  if (items.length === 0 && !orderPlaced) { navigate("/cart"); return null; }

  if (orderPlaced) return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="container py-20 text-center">
        <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
          <Check className="w-8 h-8 text-primary" />
        </div>
        <h1 className="text-2xl font-bold mb-2">Order Placed Successfully!</h1>
        <p className="text-muted-foreground mb-2">Order #NC-{Math.random().toString(36).substring(2, 10).toUpperCase()}</p>
        <p className="text-sm text-muted-foreground mb-6">You'll receive a confirmation email shortly.</p>
        <button onClick={() => navigate("/")} className="bg-primary text-primary-foreground px-6 py-2.5 rounded-lg font-medium hover:opacity-90">Continue Shopping</button>
      </div>
      <Footer />
    </div>
  );

  const handlePlaceOrder = () => {
    toast.success("Order placed successfully!");
    clearCart();
    setOrderPlaced(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container py-6">
        <h1 className="text-2xl font-bold mb-6">Checkout</h1>

        {/* Steps */}
        <div className="flex items-center gap-2 mb-8">
          {(["shipping", "payment", "confirm"] as const).map((s, i) => (
            <div key={s} className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${step === s || (s === "shipping" && step !== "shipping") || (s === "payment" && step === "confirm") ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"}`}>
                {i + 1}
              </div>
              <span className={`text-sm font-medium capitalize hidden sm:block ${step === s ? "text-foreground" : "text-muted-foreground"}`}>{s}</span>
              {i < 2 && <div className="w-8 h-px bg-border" />}
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            {step === "shipping" && (
              <div className="bg-card border rounded-lg p-6">
                <h2 className="font-bold text-lg mb-4">Shipping Address</h2>
                <div className="grid sm:grid-cols-2 gap-4">
                  {[
                    { key: "firstName", label: "First Name" }, { key: "lastName", label: "Last Name" },
                    { key: "email", label: "Email", type: "email" }, { key: "phone", label: "Phone" },
                    { key: "address", label: "Address", full: true },
                    { key: "city", label: "City" }, { key: "state", label: "State" },
                    { key: "zip", label: "ZIP Code" }, { key: "country", label: "Country" },
                  ].map(({ key, label, full, type }) => (
                    <div key={key} className={full ? "sm:col-span-2" : ""}>
                      <label className="block text-sm font-medium mb-1">{label}</label>
                      <input type={type || "text"} value={(form as any)[key]} onChange={e => updateForm(key, e.target.value)} className="w-full h-10 px-3 border rounded-md bg-background text-sm" />
                    </div>
                  ))}
                </div>
                <button onClick={() => setStep("payment")} className="mt-6 bg-primary text-primary-foreground px-8 py-2.5 rounded-lg font-medium hover:opacity-90">Continue to Payment</button>
              </div>
            )}

            {step === "payment" && (
              <div className="bg-card border rounded-lg p-6">
                <h2 className="font-bold text-lg mb-4">Payment Method</h2>
                <div className="space-y-3">
                  {paymentMethods.map(({ id, label, icon: Icon }) => (
                    <button key={id} onClick={() => setPaymentMethod(id)} className={`w-full flex items-center gap-3 p-4 border rounded-lg text-left ${paymentMethod === id ? "border-primary bg-primary/5" : "hover:bg-secondary"}`}>
                      <Icon className={`w-5 h-5 ${paymentMethod === id ? "text-primary" : "text-muted-foreground"}`} />
                      <span className="text-sm font-medium">{label}</span>
                    </button>
                  ))}
                </div>
                {paymentMethod === "card" && (
                  <div className="mt-4 space-y-3 pt-4 border-t">
                    <div><label className="block text-sm font-medium mb-1">Card Number</label><input placeholder="1234 5678 9012 3456" className="w-full h-10 px-3 border rounded-md bg-background text-sm" /></div>
                    <div className="grid grid-cols-2 gap-3">
                      <div><label className="block text-sm font-medium mb-1">Expiry</label><input placeholder="MM/YY" className="w-full h-10 px-3 border rounded-md bg-background text-sm" /></div>
                      <div><label className="block text-sm font-medium mb-1">CVV</label><input placeholder="123" className="w-full h-10 px-3 border rounded-md bg-background text-sm" /></div>
                    </div>
                  </div>
                )}
                <div className="flex gap-3 mt-6">
                  <button onClick={() => setStep("shipping")} className="px-6 py-2.5 border rounded-lg text-sm font-medium hover:bg-secondary">Back</button>
                  <button onClick={() => setStep("confirm")} className="bg-primary text-primary-foreground px-8 py-2.5 rounded-lg font-medium hover:opacity-90">Review Order</button>
                </div>
              </div>
            )}

            {step === "confirm" && (
              <div className="bg-card border rounded-lg p-6">
                <h2 className="font-bold text-lg mb-4">Review Your Order</h2>
                <div className="space-y-3 mb-6">
                  {items.map(({ product, quantity }) => (
                    <div key={product.id} className="flex items-center gap-3 text-sm">
                      <img src={product.image} alt="" className="w-12 h-12 rounded object-cover" />
                      <div className="flex-1 min-w-0"><p className="font-medium truncate">{product.title}</p><p className="text-muted-foreground">Qty: {quantity}</p></div>
                      <span className="font-bold">${(product.price * quantity).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
                <div className="border-t pt-4 mb-4">
                  <p className="text-sm"><span className="font-medium">Ship to:</span> {form.firstName} {form.lastName}, {form.address}, {form.city}, {form.state} {form.zip}</p>
                  <p className="text-sm mt-1"><span className="font-medium">Payment:</span> {paymentMethods.find(p => p.id === paymentMethod)?.label}</p>
                </div>
                <div className="flex gap-3">
                  <button onClick={() => setStep("payment")} className="px-6 py-2.5 border rounded-lg text-sm font-medium hover:bg-secondary">Back</button>
                  <button onClick={handlePlaceOrder} className="bg-sale text-sale-foreground px-8 py-2.5 rounded-lg font-bold hover:opacity-90">Place Order — ${totalPrice.toFixed(2)}</button>
                </div>
              </div>
            )}
          </div>

          {/* Order Summary */}
          <div className="bg-card border rounded-lg p-5 h-fit sticky top-32">
            <h2 className="font-bold mb-3">Order Summary</h2>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">Subtotal ({items.length} items)</span><span>${subtotal.toFixed(2)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Shipping</span><span className="text-primary font-medium">Free</span></div>
              {discount > 0 && <div className="flex justify-between text-primary"><span>Discount</span><span>-{discount}%</span></div>}
              <div className="flex justify-between font-bold text-lg pt-3 border-t"><span>Total</span><span>${totalPrice.toFixed(2)}</span></div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Checkout;

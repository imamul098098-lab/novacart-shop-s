import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import BannerSlider from "@/components/home/BannerSlider";
import FlashSale from "@/components/home/FlashSale";
import CategoryGrid from "@/components/home/CategoryGrid";
import ProductSection from "@/components/home/ProductSection";
import { getTrendingProducts, getBestSellerProducts, getProductsByCategory } from "@/data/products";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container">
        {/* Banner */}
        <div className="py-4">
          <BannerSlider />
        </div>

        {/* Categories */}
        <CategoryGrid />

        {/* Flash Sale */}
        <FlashSale />

        {/* Trending */}
        <div className="bg-surface -mx-4 px-4 rounded-lg">
          <ProductSection title="🔥 Trending Now" products={getTrendingProducts()} viewAllLink="/search?q=trending" />
        </div>

        {/* Best Sellers */}
        <ProductSection title="⭐ Best Sellers" products={getBestSellerProducts()} viewAllLink="/search?q=best" />

        {/* Category Sections */}
        <div className="bg-surface -mx-4 px-4 rounded-lg">
          <ProductSection title="📱 Electronics Deals" products={getProductsByCategory("Electronics").slice(0, 12)} viewAllLink="/category/Electronics" />
        </div>

        <ProductSection title="👔 Men's Fashion" products={getProductsByCategory("Men's Fashion").slice(0, 12)} viewAllLink="/category/Men's Fashion" />

        <div className="bg-surface -mx-4 px-4 rounded-lg">
          <ProductSection title="👗 Women's Fashion" products={getProductsByCategory("Women's Fashion").slice(0, 12)} viewAllLink="/category/Women's Fashion" />
        </div>

        <ProductSection title="💡 Recommended for You" products={getProductsByCategory("Gadgets").slice(0, 12)} viewAllLink="/category/Gadgets" />
      </main>
      <Footer />
    </div>
  );
};

export default Index;

import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Minus, Plus, Trash2, ShoppingCart, Tag } from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { useCart } from "@/contexts/CartContext";
import { toast } from "sonner";

const Cart = () => {
  const { items, updateQuantity, removeFromCart, clearCart, totalPrice, couponCode, setCouponCode, discount, applyCoupon } = useCart();
  const navigate = useNavigate();
  const subtotal = items.reduce((s, i) => s + i.product.price * i.quantity, 0);

  if (items.length === 0) return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="container py-20 text-center">
        <ShoppingCart className="w-16 h-16 text-muted mx-auto mb-4" />
        <h1 className="text-2xl font-bold mb-2">Your Cart is Empty</h1>
        <p className="text-muted-foreground mb-6">Looks like you haven't added anything yet.</p>
        <Link to="/" className="bg-primary text-primary-foreground px-6 py-2.5 rounded-lg font-medium hover:opacity-90">Continue Shopping</Link>
      </div>
      <Footer />
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container py-6">
        <h1 className="text-2xl font-bold mb-6">Shopping Cart ({items.length} items)</h1>
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Items */}
          <div className="lg:col-span-2 space-y-3">
            {items.map(({ product, quantity }) => (
              <div key={product.id} className="flex gap-4 p-4 bg-card border rounded-lg">
                <Link to={`/product/${product.id}`} className="w-20 h-20 flex-shrink-0 rounded-md overflow-hidden bg-secondary">
                  <img src={product.image} alt={product.title} className="w-full h-full object-cover" />
                </Link>
                <div className="flex-1 min-w-0">
                  <Link to={`/product/${product.id}`} className="text-sm font-medium hover:text-primary line-clamp-2">{product.title}</Link>
                  <p className="text-xs text-muted-foreground mt-0.5">{product.seller}</p>
                  <div className="flex items-center justify-between mt-2">
                    <span className="font-bold text-sale">${product.price.toFixed(2)}</span>
                    <div className="flex items-center gap-2">
                      <button onClick={() => updateQuantity(product.id, quantity - 1)} className="w-7 h-7 border rounded flex items-center justify-center hover:bg-secondary"><Minus className="w-3 h-3" /></button>
                      <span className="text-sm font-medium w-6 text-center">{quantity}</span>
                      <button onClick={() => updateQuantity(product.id, quantity + 1)} className="w-7 h-7 border rounded flex items-center justify-center hover:bg-secondary"><Plus className="w-3 h-3" /></button>
                      <button onClick={() => { removeFromCart(product.id); toast.info("Removed from cart"); }} className="ml-2 p-1.5 text-muted-foreground hover:text-sale"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Summary */}
          <div className="bg-card border rounded-lg p-5 h-fit sticky top-32">
            <h2 className="font-bold text-lg mb-4">Order Summary</h2>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span>${subtotal.toFixed(2)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Shipping</span><span className="text-primary font-medium">Free</span></div>
              {discount > 0 && <div className="flex justify-between text-primary"><span>Coupon ({discount}%)</span><span>-${(subtotal * discount / 100).toFixed(2)}</span></div>}
            </div>

            {/* Coupon */}
            <div className="mt-4 pt-4 border-t">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Tag className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                  <input value={couponCode} onChange={e => setCouponCode(e.target.value)} placeholder="Coupon code" className="w-full h-9 pl-8 pr-3 border rounded-md text-sm bg-background" />
                </div>
                <button onClick={() => { applyCoupon(); toast.info(discount > 0 ? `${discount}% discount applied!` : "Try NOVA10, NOVA20, or SAVE50"); }} className="px-3 h-9 bg-secondary text-secondary-foreground text-sm font-medium rounded-md hover:opacity-80">Apply</button>
              </div>
            </div>

            <div className="flex justify-between font-bold text-lg mt-4 pt-4 border-t">
              <span>Total</span><span>${totalPrice.toFixed(2)}</span>
            </div>

            <button onClick={() => navigate("/checkout")} className="w-full bg-primary text-primary-foreground font-semibold py-3 rounded-lg mt-4 hover:opacity-90 transition-opacity">
              Proceed to Checkout
            </button>
            <button onClick={() => { clearCart(); toast.info("Cart cleared"); }} className="w-full text-sm text-muted-foreground mt-2 hover:text-sale">Clear Cart</button>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Cart;

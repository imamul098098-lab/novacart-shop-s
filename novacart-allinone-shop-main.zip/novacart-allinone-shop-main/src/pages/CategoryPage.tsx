import { useParams } from "react-router-dom";
import { useState, useMemo } from "react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import ProductCard from "@/components/product/ProductCard";
import { getProductsByCategory } from "@/data/products";

const sortOptions = [
  { value: "relevant", label: "Most Relevant" },
  { value: "price-asc", label: "Price: Low to High" },
  { value: "price-desc", label: "Price: High to Low" },
  { value: "rating", label: "Top Rated" },
  { value: "best", label: "Best Selling" },
];

const CategoryPage = () => {
  const { name } = useParams<{ name: string }>();
  const category = decodeURIComponent(name || "");
  const [sort, setSort] = useState("relevant");
  const [page, setPage] = useState(1);
  const perPage = 24;

  const products = useMemo(() => {
    const items = getProductsByCategory(category);
    switch (sort) {
      case "price-asc": return [...items].sort((a, b) => a.price - b.price);
      case "price-desc": return [...items].sort((a, b) => b.price - a.price);
      case "rating": return [...items].sort((a, b) => b.rating - a.rating);
      case "best": return [...items].sort((a, b) => b.reviews - a.reviews);
      default: return items;
    }
  }, [category, sort]);

  const paginated = products.slice(0, page * perPage);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container py-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold">{category}</h1>
            <p className="text-sm text-muted-foreground">{products.length} products</p>
          </div>
          <select value={sort} onChange={e => setSort(e.target.value)} className="h-9 px-3 border rounded-md text-sm bg-background">
            {sortOptions.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
          {paginated.map(p => <ProductCard key={p.id} product={p} />)}
        </div>
        {paginated.length < products.length && (
          <div className="text-center mt-8">
            <button onClick={() => setPage(p => p + 1)} className="bg-primary text-primary-foreground px-8 py-2.5 rounded-lg font-medium hover:opacity-90">Load More</button>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
};

export default CategoryPage;

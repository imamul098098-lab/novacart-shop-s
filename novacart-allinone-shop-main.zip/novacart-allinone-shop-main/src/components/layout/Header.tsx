import { useState, useRef, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Search, ShoppingCart, Heart, User, Menu, ChevronDown, X } from "lucide-react";
import { useCart } from "@/contexts/CartContext";
import { useWishlist } from "@/contexts/WishlistContext";
import { searchProducts } from "@/data/products";

const categories = [
  "Electronics", "Men's Fashion", "Women's Fashion", "Shoes",
  "Beauty", "Accessories", "Home & Living", "Gadgets"
];

const Header = () => {
  const { totalItems } = useCart();
  const { totalItems: wishlistCount } = useWishlist();
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [showCategories, setShowCategories] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();
  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (query.length > 1) {
      const results = searchProducts(query).slice(0, 8);
      setSuggestions(results.map(p => p.title));
      setShowSuggestions(true);
    } else {
      setShowSuggestions(false);
    }
  }, [query]);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) setShowSuggestions(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) { navigate(`/search?q=${encodeURIComponent(query)}`); setShowSuggestions(false); }
  };

  return (
    <header className="sticky top-0 z-50">
      {/* Announcement Bar */}
      <div className="bg-primary text-primary-foreground text-xs py-1.5 text-center font-medium">
        🚚 FREE Shipping on orders over $50 | ⚡ Flash Sale — Up to 70% OFF — Limited Time!
      </div>

      {/* Main Header */}
      <div className="bg-card border-b shadow-sm">
        <div className="container flex items-center gap-4 py-3">
          {/* Mobile menu toggle */}
          <button className="lg:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>

          {/* Logo */}
          <Link to="/" className="flex-shrink-0">
            <span className="text-xl lg:text-2xl font-black text-primary tracking-tight">Nova</span>
            <span className="text-xl lg:text-2xl font-black text-foreground tracking-tight">Cart</span>
          </Link>

          {/* Search */}
          <div ref={searchRef} className="flex-1 max-w-2xl relative hidden sm:block">
            <form onSubmit={handleSearch} className="flex">
              <div className="relative flex-1">
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search products, brands and categories..."
                  className="w-full h-10 pl-4 pr-10 rounded-l-lg border border-r-0 border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
              <button type="submit" className="bg-primary text-primary-foreground px-5 rounded-r-lg hover:opacity-90 transition-opacity">
                <Search className="w-5 h-5" />
              </button>
            </form>
            {showSuggestions && suggestions.length > 0 && (
              <div className="absolute top-full left-0 right-0 bg-card border rounded-b-lg shadow-lg z-50 mt-0.5">
                {suggestions.map((s, i) => (
                  <button key={i} className="w-full text-left px-4 py-2 text-sm hover:bg-secondary transition-colors truncate" onClick={() => { setQuery(s); navigate(`/search?q=${encodeURIComponent(s)}`); setShowSuggestions(false); }}>
                    <Search className="w-3 h-3 inline mr-2 text-muted-foreground" />{s}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-1 sm:gap-3 ml-auto">
            <Link to="/login" className="hidden md:flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-primary transition-colors px-2 py-1">
              <User className="w-5 h-5" /> <span>Login</span>
            </Link>
            <Link to="/wishlist" className="relative p-2 hover:text-primary transition-colors text-muted-foreground">
              <Heart className="w-5 h-5" />
              {wishlistCount > 0 && <span className="absolute -top-0.5 -right-0.5 bg-sale text-sale-foreground text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">{wishlistCount}</span>}
            </Link>
            <Link to="/cart" className="relative p-2 hover:text-primary transition-colors text-muted-foreground">
              <ShoppingCart className="w-5 h-5" />
              {totalItems > 0 && <span className="absolute -top-0.5 -right-0.5 bg-sale text-sale-foreground text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">{totalItems > 99 ? '99+' : totalItems}</span>}
            </Link>
          </div>
        </div>

        {/* Mobile Search */}
        <div className="sm:hidden px-4 pb-3">
          <form onSubmit={handleSearch} className="flex">
            <input type="text" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search..." className="flex-1 h-9 pl-3 rounded-l-lg border border-r-0 border-input bg-background text-sm focus:outline-none" />
            <button type="submit" className="bg-primary text-primary-foreground px-4 rounded-r-lg"><Search className="w-4 h-4" /></button>
          </form>
        </div>
      </div>

      {/* Category Nav */}
      <nav className="bg-card border-b hidden lg:block">
        <div className="container flex items-center gap-1">
          <button onClick={() => setShowCategories(!showCategories)} className="flex items-center gap-1 px-4 py-2.5 bg-primary text-primary-foreground text-sm font-semibold rounded-none hover:opacity-90">
            <Menu className="w-4 h-4" /> All Categories <ChevronDown className="w-3 h-3" />
          </button>
          {categories.map(cat => (
            <Link key={cat} to={`/category/${encodeURIComponent(cat)}`} className="px-3 py-2.5 text-sm font-medium text-muted-foreground hover:text-primary transition-colors whitespace-nowrap">
              {cat}
            </Link>
          ))}
        </div>
      </nav>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-card border-b shadow-lg">
          <div className="p-4 space-y-1">
            <Link to="/login" className="flex items-center gap-2 px-3 py-2.5 text-sm font-medium rounded-md hover:bg-secondary" onClick={() => setMobileMenuOpen(false)}>
              <User className="w-4 h-4" /> Login / Sign Up
            </Link>
            <div className="border-t my-2" />
            {categories.map(cat => (
              <Link key={cat} to={`/category/${encodeURIComponent(cat)}`} className="block px-3 py-2 text-sm hover:bg-secondary rounded-md" onClick={() => setMobileMenuOpen(false)}>
                {cat}
              </Link>
            ))}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;

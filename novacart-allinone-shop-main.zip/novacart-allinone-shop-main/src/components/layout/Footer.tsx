import { Link } from "react-router-dom";

const Footer = () => (
  <footer className="bg-foreground text-primary-foreground mt-12">
    <div className="container py-10">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
        <div>
          <h3 className="font-bold text-lg mb-4"><span className="text-primary">Nova</span>Cart</h3>
          <p className="text-sm opacity-70">Shop Everything in One Place. Your trusted multi-vendor marketplace.</p>
        </div>
        <div>
          <h4 className="font-semibold mb-3 text-sm">Customer Service</h4>
          <ul className="space-y-2 text-sm opacity-70">
            <li><Link to="/help" className="hover:opacity-100">Help Center</Link></li>
            <li><Link to="/returns" className="hover:opacity-100">Returns & Refunds</Link></li>
            <li><Link to="/shipping" className="hover:opacity-100">Shipping Info</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-3 text-sm">About</h4>
          <ul className="space-y-2 text-sm opacity-70">
            <li><Link to="/about" className="hover:opacity-100">About NovaCart</Link></li>
            <li><Link to="/careers" className="hover:opacity-100">Careers</Link></li>
            <li><Link to="/seller" className="hover:opacity-100">Sell on NovaCart</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-3 text-sm">Stay Connected</h4>
          <p className="text-sm opacity-70 mb-3">Get updates on deals & promotions</p>
          <div className="flex">
            <input type="email" placeholder="Your email" className="flex-1 h-9 px-3 rounded-l-md text-sm text-foreground bg-card" />
            <button className="bg-primary px-4 rounded-r-md text-sm font-medium">Subscribe</button>
          </div>
        </div>
      </div>
      <div className="border-t border-primary-foreground/20 mt-8 pt-6 text-center text-xs opacity-50">
        © 2026 NovaCart Marketplace. All rights reserved.
      </div>
    </div>
  </footer>
);

export default Footer;

import { Link } from "react-router-dom";
import { Star, ShoppingCart, Heart } from "lucide-react";
import { useCart } from "@/contexts/CartContext";
import { useWishlist } from "@/contexts/WishlistContext";
import type { Product } from "@/data/products";
import { toast } from "sonner";

const ProductCard = ({ product }: { product: Product }) => {
  const { addToCart } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  const wishlisted = isInWishlist(product.id);

  return (
    <div className="group bg-card border rounded-lg overflow-hidden hover:shadow-lg transition-shadow relative">
      {/* Discount Badge */}
      {product.discount >= 20 && (
        <span className="absolute top-2 left-2 z-10 bg-sale text-sale-foreground text-[10px] font-bold px-1.5 py-0.5 rounded">
          -{product.discount}%
        </span>
      )}

      {/* Wishlist Button */}
      <button
        onClick={(e) => { e.preventDefault(); wishlisted ? removeFromWishlist(product.id) : addToWishlist(product); toast.success(wishlisted ? "Removed from wishlist" : "Added to wishlist"); }}
        className="absolute top-2 right-2 z-10 p-1.5 rounded-full bg-card/80 backdrop-blur-sm hover:bg-card transition-colors"
      >
        <Heart className={`w-4 h-4 ${wishlisted ? "fill-sale text-sale" : "text-muted-foreground"}`} />
      </button>

      <Link to={`/product/${product.id}`}>
        <div className="aspect-square overflow-hidden bg-secondary">
          <img src={product.image} alt={product.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" loading="lazy" />
        </div>
      </Link>

      <div className="p-3">
        <Link to={`/product/${product.id}`}>
          <h3 className="text-sm font-medium text-foreground line-clamp-2 mb-1 hover:text-primary transition-colors leading-tight">
            {product.title}
          </h3>
        </Link>

        <div className="flex items-baseline gap-2 mb-1">
          <span className="text-base font-bold text-sale">${product.price.toFixed(2)}</span>
          <span className="text-xs text-muted-foreground line-through">${product.originalPrice.toFixed(2)}</span>
        </div>

        <div className="flex items-center gap-1 mb-2">
          <div className="flex">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star key={i} className={`w-3 h-3 ${i < Math.round(product.rating) ? "fill-rating text-rating" : "text-muted"}`} />
            ))}
          </div>
          <span className="text-[10px] text-muted-foreground">({product.reviews})</span>
        </div>

        <button
          onClick={() => { addToCart(product); toast.success("Added to cart"); }}
          className="w-full flex items-center justify-center gap-1.5 bg-primary text-primary-foreground text-xs font-medium py-2 rounded-md opacity-0 group-hover:opacity-100 transition-opacity hover:opacity-90"
        >
          <ShoppingCart className="w-3.5 h-3.5" /> Add to Cart
        </button>
      </div>
    </div>
  );
};

export default ProductCard;

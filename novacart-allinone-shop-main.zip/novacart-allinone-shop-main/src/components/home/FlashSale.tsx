import { useState, useEffect } from "react";
import { Zap } from "lucide-react";
import { getFlashSaleProducts } from "@/data/products";
import ProductCard from "@/components/product/ProductCard";

const FlashSale = () => {
  const products = getFlashSaleProducts();
  const [time, setTime] = useState({ hours: 8, minutes: 45, seconds: 30 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(prev => {
        let { hours, minutes, seconds } = prev;
        seconds--;
        if (seconds < 0) { seconds = 59; minutes--; }
        if (minutes < 0) { minutes = 59; hours--; }
        if (hours < 0) { hours = 23; minutes = 59; seconds = 59; }
        return { hours, minutes, seconds };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const pad = (n: number) => n.toString().padStart(2, "0");

  return (
    <section className="py-6">
      <div className="flex items-center gap-3 mb-4">
        <div className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-sale fill-sale" />
          <h2 className="text-xl font-bold text-foreground">Flash Sale</h2>
        </div>
        <div className="flex items-center gap-1 ml-4">
          <span className="text-xs text-muted-foreground mr-1">Ends in:</span>
          {[pad(time.hours), pad(time.minutes), pad(time.seconds)].map((v, i) => (
            <span key={i} className="flex items-center">
              <span className="bg-foreground text-primary-foreground text-sm font-bold px-2 py-1 rounded">{v}</span>
              {i < 2 && <span className="text-foreground font-bold mx-0.5">:</span>}
            </span>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
        {products.slice(0, 12).map(p => <ProductCard key={p.id} product={p} />)}
      </div>
    </section>
  );
};

export default FlashSale;

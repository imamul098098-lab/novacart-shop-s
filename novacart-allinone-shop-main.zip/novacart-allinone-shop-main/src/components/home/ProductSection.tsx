import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";
import type { Product } from "@/data/products";
import ProductCard from "@/components/product/ProductCard";

interface ProductSectionProps {
  title: string;
  products: Product[];
  viewAllLink?: string;
  bgClass?: string;
}

const ProductSection = ({ title, products, viewAllLink, bgClass }: ProductSectionProps) => (
  <section className={`py-6 ${bgClass || ""}`}>
    <div className="flex items-center justify-between mb-4">
      <h2 className="text-xl font-bold text-foreground">{title}</h2>
      {viewAllLink && (
        <Link to={viewAllLink} className="flex items-center gap-1 text-sm font-medium text-primary hover:underline">
          View All <ChevronRight className="w-4 h-4" />
        </Link>
      )}
    </div>
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
      {products.slice(0, 12).map(p => <ProductCard key={p.id} product={p} />)}
    </div>
  </section>
);

export default ProductSection;

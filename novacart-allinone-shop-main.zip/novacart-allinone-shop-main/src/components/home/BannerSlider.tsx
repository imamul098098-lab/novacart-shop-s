import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import bannerFashion from "@/assets/banner-fashion.jpg";
import bannerElectronics from "@/assets/banner-electronics.jpg";
import bannerFlash from "@/assets/banner-flash.jpg";
import bannerDiscount from "@/assets/banner-discount.jpg";

const slides = [
  { image: bannerFashion, title: "Mega Fashion Sale", subtitle: "Up to 70% OFF on trending styles", link: "/category/Women's Fashion", cta: "Shop Now" },
  { image: bannerElectronics, title: "Electronics Mega Deals", subtitle: "Latest gadgets at unbeatable prices", link: "/category/Electronics", cta: "Shop Now" },
  { image: bannerFlash, title: "Flash Sale Ends Tonight", subtitle: "Hurry! Limited stock available", link: "/search?q=flash", cta: "Grab Deals" },
  { image: bannerDiscount, title: "Special Discounts", subtitle: "Up to 50% OFF on select items", link: "/search?q=special", cta: "Explore" },
];

const BannerSlider = () => {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => setCurrent(p => (p + 1) % slides.length), 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="relative w-full aspect-[3/1] overflow-hidden rounded-lg">
      {slides.map((slide, i) => (
        <div key={i} className={`absolute inset-0 transition-opacity duration-500 ${i === current ? "opacity-100" : "opacity-0 pointer-events-none"}`}>
          <img src={slide.image} alt={slide.title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-foreground/60 to-transparent flex items-center">
            <div className="pl-8 md:pl-16 max-w-md">
              <h2 className="text-2xl md:text-4xl font-black text-primary-foreground mb-2">{slide.title}</h2>
              <p className="text-sm md:text-base text-primary-foreground/80 mb-4">{slide.subtitle}</p>
              <Link to={slide.link} className="inline-block bg-primary text-primary-foreground px-6 py-2.5 rounded-md text-sm font-semibold hover:opacity-90 transition-opacity">
                {slide.cta}
              </Link>
            </div>
          </div>
        </div>
      ))}
      <button onClick={() => setCurrent(p => (p - 1 + slides.length) % slides.length)} className="absolute left-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-card/70 hover:bg-card transition-colors">
        <ChevronLeft className="w-5 h-5" />
      </button>
      <button onClick={() => setCurrent(p => (p + 1) % slides.length)} className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-card/70 hover:bg-card transition-colors">
        <ChevronRight className="w-5 h-5" />
      </button>
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-2">
        {slides.map((_, i) => (
          <button key={i} onClick={() => setCurrent(i)} className={`w-2.5 h-2.5 rounded-full transition-colors ${i === current ? "bg-primary" : "bg-card/60"}`} />
        ))}
      </div>
    </div>
  );
};

export default BannerSlider;

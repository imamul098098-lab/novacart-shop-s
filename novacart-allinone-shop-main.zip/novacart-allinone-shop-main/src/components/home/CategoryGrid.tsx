import { Link } from "react-router-dom";
import { Smartphone, Shirt, ShoppingBag, Footprints, Sparkles, Watch, Home, Cpu } from "lucide-react";

const cats = [
  { name: "Electronics", icon: Smartphone, color: "bg-blue-50 text-blue-600" },
  { name: "Men's Fashion", icon: Shirt, color: "bg-green-50 text-green-600" },
  { name: "Women's Fashion", icon: ShoppingBag, color: "bg-pink-50 text-pink-600" },
  { name: "Shoes", icon: Footprints, color: "bg-orange-50 text-orange-600" },
  { name: "Beauty", icon: Sparkles, color: "bg-purple-50 text-purple-600" },
  { name: "Accessories", icon: Watch, color: "bg-yellow-50 text-yellow-600" },
  { name: "Home & Living", icon: Home, color: "bg-teal-50 text-teal-600" },
  { name: "Gadgets", icon: Cpu, color: "bg-red-50 text-red-600" },
];

const CategoryGrid = () => (
  <section className="py-6">
    <h2 className="text-xl font-bold text-foreground mb-4">Shop by Category</h2>
    <div className="grid grid-cols-4 md:grid-cols-8 gap-3">
      {cats.map(({ name, icon: Icon, color }) => (
        <Link key={name} to={`/category/${encodeURIComponent(name)}`} className="flex flex-col items-center gap-2 p-3 rounded-lg hover:bg-secondary transition-colors group">
          <div className={`w-12 h-12 rounded-full flex items-center justify-center ${color} group-hover:scale-110 transition-transform`}>
            <Icon className="w-6 h-6" />
          </div>
          <span className="text-xs font-medium text-center text-muted-foreground group-hover:text-foreground">{name}</span>
        </Link>
      ))}
    </div>
  </section>
);

export default CategoryGrid;
